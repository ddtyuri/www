﻿<?php
//公共信息配置

//数据库配置信息
define("HOST","127.0.0.1");	//主机名
define("USER","root");		//账号
define("PASS","8vdyBMU8");		//密码
define("DBNAME","jnyo");	//数据库名