        <div id="mws-sidebar">
        	<div id="mws-searchbox" class="mws-inset">
            	<form action="#">
                	<input type="text" class="mws-search-input" />
                    <input type="submit" class="mws-search-submit" />
                </form>
            </div>
            <div id="mws-navigation">
            	<ul>
                	<li><a href="#" class="mws-i-24 i-home">Dashboard</a></li>
                	<li><a href="#" class="mws-i-24 i-chart">Charts</a></li>
                	<li><a href="../product/index.php" class="mws-i-24 i-day-calendar">商品管理</a></li>
                	<li><a href="../ad/index.php" class="mws-i-24 i-file-cabinet">广告管理</a></li>
                	<li ><a href="../user/index.php" class="mws-i-24 i-table-1">用户管理</a></li>
                	<li>
                    	<a href="#" class="mws-i-24 i-list">账号状态审核</a>
                        <ul>
                        	<li><a href="../individual/index.php">广告主（个人）审核</a></li>
                        	<li><a href="../enterprise/index.php">广告主（企业）审核</a></li>
                        </ul>
                    </li>
                	<li><a href="../purchase/index.php" class="mws-i-24 i-cog">商品结算审核</a></li>
                	<li><a href="#" class="mws-i-24 i-text-styling">Typography</a></li>
                	<li><a href="#" class="mws-i-24 i-blocks-images">Grids &amp; Panels</a></li>
                	<li><a href="#" class="mws-i-24 i-polaroids">Gallery</a></li>
                	<li><a href="#" class="mws-i-24 i-alert-2">Error Page</a></li>
                	<li>
                    	<a href="#" class="mws-i-24 i-pacman">
                        	Icons <span class="mws-nav-tooltip">2000+</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>